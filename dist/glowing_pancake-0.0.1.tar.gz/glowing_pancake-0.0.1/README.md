# glowing-pancake
A logger for Python, merely an essay in Python Package development. Nothing serious.
